# MERN Tasks

Two small projects:

1. `signup-app/` - Sign Up process: React + Express.js + REST API + MongoDB
2. `crud-app/` - CRUD on an array of items: HTML + CSS + Express.js + REST API

## 1. Sign Up app

Needs MongoDB running locally (or an Atlas URI).

```bash
# terminal 1 - API on :5000
cd signup-app/server
cp .env.example .env      # edit MONGO_URI if needed
npm install
npm start

# terminal 2 - React on :3000
cd signup-app/client
npm install
npm start
```

Endpoint: `POST /api/signup` with `{ name, email, password }`
- 201 created, 400 validation error, 409 email already registered
- Password is hashed with bcrypt before saving

## 2. CRUD app

```bash
cd crud-app
npm install
npm start
```

Open http://localhost:3000

| Method | Route            | Action        |
|--------|------------------|---------------|
| GET    | /api/items       | list all      |
| GET    | /api/items/:id   | get one       |
| POST   | /api/items       | create        |
| PUT    | /api/items/:id   | update        |
| DELETE | /api/items/:id   | delete        |

Items live in an in-memory array on the server, so they reset on restart (starts with Book 250 and Pen 25, as in the sketch).
