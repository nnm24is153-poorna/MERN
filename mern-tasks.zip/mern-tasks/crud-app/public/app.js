const API = '/api/items';

const form = document.getElementById('item-form');
const nameInput = document.getElementById('name');
const priceInput = document.getElementById('price');
const submitBtn = document.getElementById('submit-btn');
const cancelBtn = document.getElementById('cancel-btn');
const message = document.getElementById('message');
const tbody = document.getElementById('items-body');

let editingId = null;

async function loadItems() {
  const res = await fetch(API);
  const items = await res.json();
  renderItems(items);
}

function renderItems(items) {
  tbody.innerHTML = '';
  if (items.length === 0) {
    const tr = document.createElement('tr');
    tr.innerHTML = '<td class="empty" colspan="4">No items yet</td>';
    tbody.appendChild(tr);
    return;
  }
  items.forEach((item) => {
    const tr = document.createElement('tr');

    [item.id, item.name, item.price].forEach((value) => {
      const td = document.createElement('td');
      td.textContent = value; // textContent avoids HTML injection
      tr.appendChild(td);
    });

    const actions = document.createElement('td');
    actions.className = 'actions-cell';

    const editBtn = document.createElement('button');
    editBtn.className = 'btn edit';
    editBtn.textContent = 'Edit';
    editBtn.addEventListener('click', () => startEdit(item));

    const delBtn = document.createElement('button');
    delBtn.className = 'btn delete';
    delBtn.textContent = 'Delete';
    delBtn.addEventListener('click', () => deleteItem(item.id));

    actions.append(editBtn, delBtn);
    tr.appendChild(actions);
    tbody.appendChild(tr);
  });
}

function startEdit(item) {
  editingId = item.id;
  nameInput.value = item.name;
  priceInput.value = item.price;
  submitBtn.textContent = 'Update';
  cancelBtn.classList.remove('hidden');
  message.textContent = '';
  nameInput.focus();
}

function resetForm() {
  editingId = null;
  form.reset();
  submitBtn.textContent = 'Submit';
  cancelBtn.classList.add('hidden');
}

async function deleteItem(id) {
  if (!confirm('Delete this item?')) return;
  const res = await fetch(`${API}/${id}`, { method: 'DELETE' });
  if (!res.ok) {
    message.textContent = (await res.json()).error || 'Delete failed';
    return;
  }
  if (editingId === id) resetForm();
  loadItems();
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  message.textContent = '';

  const payload = { name: nameInput.value, price: priceInput.value };
  const url = editingId ? `${API}/${editingId}` : API;
  const method = editingId ? 'PUT' : 'POST';

  const res = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    message.textContent = (await res.json()).error || 'Something went wrong';
    return;
  }

  resetForm();
  loadItems();
});

cancelBtn.addEventListener('click', resetForm);

loadItems();
